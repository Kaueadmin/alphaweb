./ExcluirExpiradoApi.sh 123456

