<?php

date_default_timezone_set("America/Sao_Paulo");
session_start();
include "../../../config/conexao.php";
$dominio = $_SERVER["HTTP_HOST"];
$token = $token;

date_default_timezone_set("America/Sao_Paulo");
define("DB_SERVER", $server);
define("DB_USERNAME", $user);
define("DB_PASSWORD", $pass);
define("DB_NAME", $db);
try {
    $pdo = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_NAME, DB_USERNAME, DB_PASSWORD);
    $pdo->exec("set names utf8");
} catch (PDOException $e) {
    exit("Falha ao conectar no banco de dados.");
}

?>