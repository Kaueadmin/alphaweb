<?php

session_start();

if (isset($_POST["tokenadiquirido"])) {
    $token = $_POST["tokenadiquirido"];
    $dominio = $_SERVER["HTTP_HOST"];

    $fp = fopen("config/conexao.php", "w");
    fwrite($fp, "<?php \n");
    fwrite($fp, "\$token = '" . $token . "';\n");
    fwrite($fp, "?>");
    fclose($fp);
}

if (isset($_POST["hostdb"]) && isset($_POST["usuariodb"]) && isset($_POST["senhadb"]) && isset($_POST["bancodb"])) {
    $server = $_POST["hostdb"];
    $user = $_POST["usuariodb"];
    $pass = $_POST["senhadb"];
    $db = $_POST["bancodb"];

    $fp = fopen("config/conexao.php", "a");
    fwrite($fp, "\n<?php \n");
    fwrite($fp, "\$server = '" . $server . "';\n");
    fwrite($fp, "\$user = '" . $user . "';\n");
    fwrite($fp, "\$pass = '" . $pass . "';\n");
    fwrite($fp, "\$db = '" . $db . "';\n");
    fwrite($fp, "?>");
    fclose($fp);

    $conn = new mysqli($server, $user, $pass, $db);
    if ($conn->connect_error) {
        exit("Connection failed: " . $conn->connect_error);
    }

    // Function to import the database from SQL file
    function importDatabase($filename, $connection) {
        $sql = file_get_contents($filename);

        if ($connection->multi_query($sql) === TRUE) {
            do {
                if ($result = $connection->store_result()) {
                    $result->free();
                }
            } while ($connection->more_results() && $connection->next_result());
        } else {
            exit("Error importing database: " . $connection->error);
        }
    }

    importDatabase("./lib/pro.sql", $conn);

    $_SESSION["loginsucesso"] = "<div>Painel instalado com sucesso!!</div>";
    header("Location: index.php");
    unlink("./lib/pro.sql");
    exit;
}

?>